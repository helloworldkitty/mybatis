package com.mapper;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Before;
import org.junit.Test;

import com.beans.ReceiverAddress;
import com.util.SQLSessionUtil;

public class AddressMapperTest {
	AddressMapper  dao =null;
		
	@Before
	public void testBefore(){
		    SqlSession sqlSession=  SQLSessionUtil.createSqlSession();
		   dao=sqlSession.getMapper(AddressMapper.class);
		
	}
	
	@Test
	public void testListAll() {
		List<ReceiverAddress> list=   dao.listAll();
		System.out.println(list.size());
		for (ReceiverAddress receiverAddress : list) {
			System.out.println(receiverAddress);
		}
	}
	
	@Test
	public void test(){
		
		ReceiverAddress  re=new ReceiverAddress();
		re.setAddress(new String[]{"�㶫ʡ","������","�Ʒ�·","�����²��ϴ���ԺG11��4¥"});
		re.setPhone("18828282828");
		re.setReceiver("лĳ");
		re.setStatus(1);
		re.setTag("��˾");
		
		dao.addAdress(re);
		
	}

}
