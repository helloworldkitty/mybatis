package com.util;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;
import org.apache.ibatis.type.TypeHandler;
/**
 * 
 * @author Administrator
 * String[] --->varchar
 * ���ɵ�ת��
 * String  sql="insert into address values(null,?);
 * PreparamStatment pstm=conn.preparament(sql);
 *  
 * pstm.setString(1,  )
 *  
 */
@MappedTypes(value = { String[].class})
@MappedJdbcTypes(value = { JdbcType.VARCHAR})
public class SelfTypeHandle implements TypeHandler<String[]> {
	@Override
	public void setParameter(PreparedStatement ps, int i, String[] parameter,
			JdbcType jdbcType) throws SQLException {
	      // ƾ�裺
		   if(parameter==null){
			   // ps.setString(i,Types.VARCHAR);
			   //ps.setString(parameterIndex, x);
			   ps.setNull(i,Types.VARCHAR);
		   }else{
			   StringBuffer  sb=new StringBuffer();
			for (String string : parameter) {
				sb.append(string.trim()+",");
			} 
			   // ȥ�����һ��,
			  sb.deleteCharAt(sb.length()-1);
			  System.out.println(sb.toString());
			  ps.setString(i,sb.toString()); 
		   }
	}

	@Override
	public String[] getResult(ResultSet rs, String columnName)
			throws SQLException {


		  String values= rs.getString(columnName);
		  return changeStringToArray(values);
	}

	@Override
	public String[] getResult(ResultSet rs, int columnIndex)
			throws SQLException {
		
	     String values=   rs.getString(columnIndex);
		return changeStringToArray(values);
	}

	@Override
	public String[] getResult(CallableStatement cs, int columnIndex)
			throws SQLException {
		
		 String value= cs.getString(columnIndex);
		 return changeStringToArray(value);
	}
	
	
	private String[] changeStringToArray(String value){
		 
	       String [] str=value.split(",");
	       return str;
		
	}

}
