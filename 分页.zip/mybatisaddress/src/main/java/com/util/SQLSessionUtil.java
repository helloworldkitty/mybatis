package com.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SQLSessionUtil {  
	private static SqlSessionFactory facory;
	private static InputStream  is;
	static{
		 String  config="mybatis-config.xml";
		 try {
			 is=  Resources.getResourceAsStream(config);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private  static  SqlSessionFactory initFacoty(){
		if(facory==null){
			facory=new SqlSessionFactoryBuilder().build(is);
		}
		return facory;
		
	}
	public  static SqlSession createSqlSession(){
		return initFacoty().openSession(true);
	}
	
	
	
}
