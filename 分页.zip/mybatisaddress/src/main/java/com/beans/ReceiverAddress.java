package com.beans;

import java.util.Arrays;

/**
 * 
 * @author Administrator
 * �ջ��ַ
 */
public class ReceiverAddress {
   private int id;
   private String receiver;
   private String[] address;
   private String phone;
   private String tag;
   private int status;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getReceiver() {
	return receiver;
}
public void setReceiver(String receiver) {
	this.receiver = receiver;
}



public String[] getAddress() {
	return address;
}
public void setAddress(String[] address) {
	this.address = address;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getTag() {
	return tag;
}
public void setTag(String tag) {
	this.tag = tag;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
@Override
public String toString() {
	return "ReceiverAddress [id=" + id + ", receiver=" + receiver
			+ ", address=" + Arrays.toString(address) + ", phone=" + phone
			+ ", tag=" + tag + ", status=" + status + "]";
}



   
   
  
   
}
