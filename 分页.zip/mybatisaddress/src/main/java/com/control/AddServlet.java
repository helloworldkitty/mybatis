package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.ReceiverAddress;
import com.service.ReceiverAddressService;

public class AddServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
           doPost(request, response);	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        
        String person= request.getParameter("man");
        String phone= request.getParameter("phone");
        String tag=request.getParameter("tag");
        String[] str= request.getParameterValues("address");
        
        for (String string : str) {
			System.out.println(string);
		}
        ReceiverAddress add=new ReceiverAddress();
        add.setAddress(str);
        add.setPhone(phone);
        add.setReceiver(person);
        add.setTag(tag);
        add.setStatus(1);
        
        ReceiverAddressService service=new ReceiverAddressService();
        boolean  flag= service.addReceiverAddress(add);
        if(flag){
        	request.getRequestDispatcher("ListByPageServlet").forward(request, response);
        }else{
        	request.getRequestDispatcher("add.jsp").forward(request, response);
        }
		
	}

}
