package com.beans;

public class Teacher {
   private int id;
   private String tname;
   private String tsex;
   private int tage;
   
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTname() {
	return tname;
}
public void setTname(String tname) {
	this.tname = tname;
}
public String getTsex() {
	return tsex;
}
public void setTsex(String tsex) {
	this.tsex = tsex;
}
public int getTage() {
	return tage;
}
public void setTage(int tage) {
	this.tage = tage;
}
@Override
public String toString() {
	return "Teacher [id=" + id + ", tname=" + tname + ", tsex=" + tsex
			+ ", tage=" + tage + "]";
}
}
