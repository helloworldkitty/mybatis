package com.beans;
/**
 * 
 * @author Administrator
 * ��Ʒ��ʵ����
 */
public class Goods {
   private int id;
   private String gname;
   private double gprice;
   private int gnum;
   private String gtype;
   private int status;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getGname() {
	return gname;
}
public void setGname(String gname) {
	this.gname = gname;
}
public double getGprice() {
	return gprice;
}
public void setGprice(double gprice) {
	this.gprice = gprice;
}
public int getGnum() {
	return gnum;
}
public void setGnum(int gnum) {
	this.gnum = gnum;
}
public String getGtype() {
	return gtype;
}
public void setGtype(String gtype) {
	this.gtype = gtype;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
@Override
public String toString() {
	return "Goods [id=" + id + ", gname=" + gname + ", gprice=" + gprice
			+ ", gnum=" + gnum + ", gtype=" + gtype + ", status=" + status
			+ "]";
}
   
}
