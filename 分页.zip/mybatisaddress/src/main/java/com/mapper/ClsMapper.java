package com.mapper;

import java.util.List;
import java.util.Map;

import com.beans.Cls;
import com.beans.Student;
import com.beans.Teacher;

public interface ClsMapper {
	 public List<Cls> listClsByCName(String cno);

	 public int addCls(Map<String,Object> map);
 
	 public int addStudent(Student s);
	 
	 public int addTeacher(Teacher t);
	 
	 
	 public List<Cls> getClassByCno(String cno);
	
}
