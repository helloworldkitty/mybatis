package com.beans;

public class Student {
    private int id;
    private String sname;
    private String sex;
    private int sage;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	
	
	public int getSage() {
		return sage;
	}
	public void setSage(int sage) {
		this.sage = sage;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", sname=" + sname + ", sex=" + sex
				+ ", sage=" + sage + "]";
	}
    
    
}
