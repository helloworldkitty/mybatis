package com.mapper;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.junit.Before;
import org.junit.Test;

import com.beans.Goods;
import com.util.SQLSessionUtil;

public class GoodsMapperTest {

	GoodsMapper  dao =null;
	
@Before
public void testBefore(){
	    SqlSession sqlSession=  SQLSessionUtil.createSqlSession();
	   dao=sqlSession.getMapper(GoodsMapper.class);
	
}
@Test
public void testListClsByCName() {
	
	
//	List<Goods> list=  dao.listByParams(null);
	
//	Map<String,Object> map=new HashMap<String,Object>();
//	map.put("gtype", "�Ե�");
//	List<Goods> list=dao.listByParams(map);
//	
//	for (Goods goods : list) {
//		System.out.println(goods);
//	}
	
	
	
	Map<String,Object> map=new HashMap<String,Object>();
//	map.put("gprice", 8);
//	map.put("gtype", "�Ե�");
	
	// map.put("type", 1);
	map.put("gname", "Ͱ��");
	List<Goods> list=dao.listByParams(map);
	
	for (Goods goods : list) {
		System.out.println(goods);
	}
}

}
