package com.service;

import java.util.List;
import java.util.Map;

import com.beans.Goods;
import com.mapper.GoodsMapper;
import com.util.SQLSessionUtil;

public class GoodsService {
	  GoodsMapper  dao=null;
	  
	  public GoodsService(){
		  dao=SQLSessionUtil.createSqlSession().getMapper(GoodsMapper.class);
	  }
	  
	

	  public  List<Goods> ListByParams(Map<String,Object> map){
		   List<Goods> list= dao.listByParams(map);
		  return list;
	  }
	  /**
	   * 
	   * @param map
	   * @return  ��ȡ��¼��
	   */
	  public int getCount(Map<String,Object> map){
		  return dao.getCount(map);
	  }
	  /**
	   * 
	   * @param map
	   * @return
	   * ��ȡ��ҳ��
	   */
	  public  int getPages(Map<String,Object> map,int page){
		   int num=getCount(map);
		   int pages=(int) Math.ceil((double)num/page);
		   return pages;
	  }
	  
}
