package com.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.Goods;
import com.google.gson.Gson;
import com.service.GoodsService;

public class ListGoodsServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
         doPost(request, response);
		
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
         
		request.setCharacterEncoding("utf-8");
		Map<String,Object> map=new HashMap<String,Object>();
		int index=1;
        int page=3;
        //��ҳ���ȡ��Ʒ�����ƣ�֧��ģ������: Ͱ��
        String gname=request.getParameter("gname");
        if(gname!=null && !"".equals(gname.trim())){
        	map.put("gname", "%"+gname+"%");
        }
        
        //��ҳ���ȡ��Ʒ��ɸѡ�۸�> ��ͼ۸�
        String gprice= request.getParameter("gprice");
        System.out.println(gprice);
        if(gprice!=null && !"".equals(gprice.trim())){
        	map.put("gprice", Double.parseDouble(gprice));
        }
        //��ȡҳ���Ӧ������Ĺ��� type=1��gprice  type=2�������� 
        String type= request.getParameter("type");
         map.put("type", type);
         
         //��ҳ���ȡ ��Ʒ�����ͣ��ԵĻ����õ�
        String gtype= request.getParameter("gtype");
        if(gtype!=null &&!"".equals(gtype.trim())){
        	map.put("gtype", gtype);
        }
        //��ҳ
         String strIndex=request.getParameter("index");
        if(strIndex!=null && !"".equals(strIndex.trim())){
        	index=Integer.parseInt(strIndex);
        }
        
        map.put("index",(index-1)*page);
        map.put("page", page);
        
        GoodsService  service=new GoodsService();
        //�õ���Ӧ�ļ���
        List<Goods> list= service.ListByParams(map);
        //�õ��ܼ�¼��
        int nums=service.getCount(map);
        //��ҳ��:
        int pages=service.getPages(map, page);
        
        
        // ��������Gson���ݵĸ�ʽ���ݵ�ҳ��
        
        HashMap<String,Object> mapDate=new HashMap<String,Object>();
        mapDate.put("data",list);
        mapDate.put("cur", index);
        mapDate.put("nums", nums);
        mapDate.put("pages", pages);
        
		Gson  gson=new Gson();
	    String strList=gson.toJson(mapDate);
		
         
	    response.setCharacterEncoding("utf-8");
	    response.getWriter().write(strList);
		
		
	}

}
