package com.mapper;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.junit.Before;
import org.junit.Test;

import com.beans.Cls;
import com.beans.Student;
import com.beans.Teacher;
import com.util.SQLSessionUtil;

public class ClsMapperTest {

	ClsMapper  dao =null;
	
	@Before
	public void testBefore(){
		    SqlSession sqlSession=  SQLSessionUtil.createSqlSession();
		   dao=sqlSession.getMapper(ClsMapper.class);
		
	}
	@Test
	public void testListClsByCName() {
		  List<Cls> list= dao.listClsByCName("0723");
		  for (Cls cls : list) {
			System.out.println(cls);
		}
	}
	
	@Test
	public void test1(){
		Student s=new Student();
		s.setSname("xgr");
		s.setSex("Ů");
		s.setSage(20);
		dao.addStudent(s);
		
		
	}
	
	@Test
	public void test2(){
		Teacher  t=new Teacher();
		t.setTname("xgr2");
		t.setTsex("��");
		t.setTage(20);
		dao.addTeacher(t);
		
	}
	
	
	// mybatis: 3.4.5:  ��֧�֣� @mapping()
	@Test
	public  void test(){
		// ͬʱ����һ��ѧ��: 
		Student s=new Student();
		s.setSname("ren");
		s.setSex("Ů");
		s.setSage(20);
		dao.addStudent(s);
		
		
		
		// ͬʱ����һ����ʦ
		Teacher  t=new Teacher();
		t.setTname("xiao");
		t.setTsex("��");
		t.setTage(20);
		dao.addTeacher(t);
		
		// 
		
		Map<String,Object> map=new HashMap<String,Object>();
		
	    map.put("cno", "0723");
	    map.put("cname", "java����");
	    map.put("tid",t.getId() );
	    map.put("sid", s.getId());
		dao.addCls(map);
		
	}
	
	@Test
	public void test4(){
		List<Cls> list= dao.getClassByCno("0723");
		for (Cls cls : list) {
			System.out.println(cls);
		}
	}

}
