package com.service;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;

import com.beans.ReceiverAddress;
import com.mapper.AddressMapper;
import com.util.SQLSessionUtil;

public class ReceiverAddressService {
    
	AddressMapper dao  =null;
	SqlSession   sqlSession=null;
	/**
	 * ���췽�����г�ʼ��
	 */
	public ReceiverAddressService(){
	    sqlSession= SQLSessionUtil.createSqlSession();
		dao=sqlSession.getMapper(AddressMapper.class);
	}
	/**
	 * 
	 * @param index: �����ҳ��1��2��3
	 * @param page : һҳ��ʾ����
	 * @return
	 */
	public List<ReceiverAddress> listByPage(int index,int page){
		//offset   limit
		//  0,      page
		// (index-1)*page
		RowBounds row=new RowBounds((index-1)*page, page);
		List<ReceiverAddress>  list= sqlSession.selectList("com.mapper.AddressMapper.listAll", null, row);
		return list;
	}
	
	public boolean addReceiverAddress(ReceiverAddress add){
		int num= dao.addAdress(add);
		if(num>0){
			return true;
		}
		return false;
	}
	
	
	
	
	
}
