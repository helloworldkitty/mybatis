package com.mapper;

import java.util.List;

import com.beans.ReceiverAddress;

public interface AddressMapper {
  
	public List<ReceiverAddress> listAll();
	
	
	public int addAdress(ReceiverAddress  add);
}
