package com.beans;

import java.util.List;

/**
 * 
 * @author Administrator
 *     �༶��  
 *     ��ʾ���а༶�������ʵ���ࣺ
 *     
 */
public class Cls {
   private int id;
   private String cno;
   private String cname;
   // tid:  --->������teacher
   private Teacher teacher;
   // sid:
   private List<Student> student;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCno() {
	return cno;
}
public void setCno(String cno) {
	this.cno = cno;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public Teacher getTeacher() {
	return teacher;
}
public void setTeacher(Teacher teacher) {
	this.teacher = teacher;
}
public List<Student> getStudent() {
	return student;
}
public void setStudent(List<Student> student) {
	this.student = student;
}
@Override
public String toString() {
	return "Cls [id=" + id + ", cno=" + cno + ", cname=" + cname + ", teacher="
			+ teacher + ", student=" + student + "]";
}
}
